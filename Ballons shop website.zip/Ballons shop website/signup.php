<?php


$email = $_POST['email'];
$password = $_POST['psw];
$passwordConfirm = $_POST[''psw-repeat'];


$data = $_POST;

if (empty($data['psw']) ||
    empty($data['email']) ||
    empty($data['psw-repeat'])) {
    
    die('Please fill all required fields!');
}

if ($data['password'] !== $data['password_confirm']) {
   die('Password and Confirm password should match!');   
}

?>